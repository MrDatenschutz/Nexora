Linux Handbook:

This handbook aims to show you commands for your Distro or for the Terminal if might have forgotten them or if you are learning them. This Handbook is only for new users.



General Knowledge:

&#x09;never type sudo rm -rf because this will remove everthing in your root Folder (Linux equivalent to system32). you can use that command to remove something specificly in 	your Root Folder or in a Sub Folder (e.g. sudo rm -rf/home/your\_user/your\_folder\_name)

&#x09;for copy and pasting use: ctrl + shift + c/v you can Change this in your terminal Settings to just use ctrl + c/v. Normally this is only for your terminal so everywhere 	you could still use ctrl + c/v. there is also a another copy function that only saves the recent stuff you marked which you can insert by Pressing your mouse Wheel 	(this is seperate to your normal clipboard)

&#x09;.sh files are the Linux equivalent to Windows Batch files

&#x09;you can Pipe something which means you can get the Output form one Programm and give it as a input for the next one. (e.g. fortune | cowsay)

&#x09;Linux is just the Kernel which comunicates with with your Hardware. A Distribution is just the rest, so stuff like a package Manager.

&#x09;-h or --h after a command Displays what you can do (e.g. cava -h)



Debian/Ubuntu/Mint:

&#x09;Update: sudo apt update \&\& sudo apt upgrade



&#x09;install a .deb file: sudo dpkg -i packageName



&#x09;remove a .deb file: sudo



&#x09;install something from Repo: sudo apt install packageName



&#x09;reomve something you downloaded from the Repo: sudo apt remove packageName



&#x09;(e.g. sudo apt install cowsay)

&#x09;(e.g. sudo apt remove cowsay)



Arch/CachyOS/Manjaro:

&#x09;Update: sudo pacman -Syu



&#x09;install something from Repo: sudo pacman -S packageName



&#x09;remove something you downloaded from the Repo: sudo pacman -R packageName



&#x09;(e.g. sudo pacman -S cowsay)

&#x09;(e.g. sudo pacman -R cowsay)



&#x09;When installing something from the AUR (Arch User Repository) be careful what you download because there can be malicious files 



Fedora/Nobara/red hat enterprise linux:

&#x09;Update: Sudo dnf upgrade



&#x09;install a .rpm file: sudo rpm -i path\_to\_file



&#x09;remove a .rpm file: sudo rpm -e packageName



&#x09;(e.g. sudo rpm -i openrgb.rpm -> make sure you're in the correct folder)

&#x09;(e.g. sudo rpm -e openrgb)



&#x09;install something from Repo: sudo dnf install packageName



&#x09;remove something you downloaded from the Repo: sudo dnf remove packageName



&#x09;(e.g. sudo dnf install cowsay)

&#x09;(e.g. sudo dnf remove cowsay)



General Linux commands:



&#x09;ls -> List files

&#x09;cd -> Change Directory

&#x09;(e.g. cd \~/Downloads -> to go to Downloads Folder in terminal. \~ stands for your Home folder)

&#x09;sudo -> Execute command as Root (Admin)

&#x09;rm -> Remove files

&#x09;su - -> Login as Root (Admin)

&#x09;sudo shutdown (now) -> to shutdown in 1 min or now

&#x09;ctrl + c stops a Process in a terminal window





KDE Desktop Environment:



&#x09;Super (Windows Key) + Esc -> Open Task Manager (System Monitor)

&#x09;Ctrl + Alt + t -> open Terminal (Konsole)

&#x09;Super (Windows Key) + i -> open Settings

&#x09;Super (Windows Key) + e -> Open file Manager (Dolphin)

&#x09;Super (Windows Key) or Alt + spacebar -> to search for files



Gnome Desktop Environment:



Getting Help:



&#x09;Make sure you read error you get throughly to make sure that you know what to ask

&#x09;You can ask a friend, a LLM (like duck.ai or chatgpt.com), Reddit or the Documentation of your Distro or from the Distro your Distro is based on for help

&#x09;When pasting commands to your Terminal make sure to read then beforhand so that you know what your doing.

&#x09;Make shure what package Manager (pacman, dnf) you use or the Distro/ the Distro your Distro is based on.

&#x09;LLM: LLM make error so beware which commands you copy and use.



Text Editor:



&#x09;for new Linux user nano is very easy. you can type nano filename.filetype after you cd into the Right Directory. you can save with ctrl + s and Exit with ctrl + x. Normally the keybinds are displayed at the Bottom of the terminal screen.



Switching Distros:



&#x09;Your first Distro should be a easy Distro to get you to try Linux out like Mint or Bazzite where everthing works out of the box. then you should look a other Distros to see what they have what your current Distro doesnt have or what you like mor About that Distro. or you could just try a new Window Manager/Desktop Environment. it is recommended to switch Distros a few times to see what you like the most. For finding new Distros you can use distrowatch or distrosea to search for new ones.

&#x20;

zip/tar.xz:



&#x09;when using a file Manager you should have the Option to unpack a .zip or .tar file. If not you can download ark or any other Programm that does the same from your repo. Ark is installed by Default in KDE



Flatpak/appimage:



&#x09;Flatpaks are Programms that work on any Distro and are in a sandbox so that it cant destroy your pc. A appimage is a Programm that works on any Linux Distro, you can open it by double clicking on it in your file Manager.



immutable/mutable:



&#x09;A immutable OS is a OS that locks some files in read only so that you cant edit these files. The result of this is that you cant install Programms normally. (popular Immutable Distros are: Bazzite and SteamOS)



Cool cli apps or Programms:

&#x09;Cava - a Audio visualitation tool

&#x09;cowsay - a tool to let creature say some text you give it

&#x09;fortune - gives out a Quote or text

&#x09;spotui - a Command line interface (cli) Version of Spotify

&#x09;fastfetch - gives a ascii logo of your Distro out and some System specs. It can also Display a Picture instead of ascii.

&#x09;fetch - fastfetch just with a 3d ascii logo

&#x09;prism launcher - Linux native minecraft launcher with mod support for modrinth and curseforge mods.



